require 'prototype_legacy_helper'
